# HenLin_CloudQuiz_Hack

如果你在考試期間使用此App，後果自負

#  使用方法
翰林的頁面>右鍵檢查>Console  
要等一下
